<?php

session_start();
$url = "http://10.183.252.68/sing9/back/PicBack.php";

$jsonPic = file_get_contents($url);

echo $jsonPic;