
<?php
header('Content-Type: application/json');
header("Content-type:application/json; charset=UTF-8");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: GET-check=0, pre-check=0", false);
ob_start();
//$_SESSION['skill_sent'];
//Skill = $_SESSION['skill_sent'];
$_REQUEST['skill'];
$Skill = $_REQUEST['skill'];
//echo $Skill;
//session_start();
// $url = "http://10.183.252.51/sing9/web/HomeBack.php";

//         $json = file_get_contents($url);
//         $jsoned = json_encode($json,JSON_UNESCAPED_UNICODE);
// 		//print_r($json);
//         print_r($jsoned);
// echo $_SESSION['skill_sent'];
// $Skill = $_SESSION['skill_sent'];

// $a = ($_SESSION['skill_sent']);


//require_once "http://localhost/sing9/web/login_front.php";
//session_start();
	//header('Content-Type: application/json');
	//header("Content-type:application/json; charset=UTF-8");
	//header("Cache-Control: no-store, no-cache, must-revalidate");
	//header("Cache-Control: GET-check=0, pre-check=0", false);


$Db_Servername = 'webkm'; 
$Db_Username = 'root'; 
$Db_Password = 'dbwebkm@2016'; 
$Db_name = 'webkm'; 

$conn = mysqli_connect($Db_Servername, $Db_Username, $Db_Password, $Db_name);
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}
//echo ($_SESSION['skill_sent']);

//echo $_SESSION['skill_sent'];
//echo $_SESSION['skill_sent'];

//echo $Skill;
//echo("<br>");
//echo ($_SESSION['skill_sent']);

//print_r($Skill);


$SkillEx = explode("|",str_replace('"','',$Skill));
//print_r( $SkillEx);
//print_r($SkillEx);
//print_r($SkillEx);
//echo $SkillEx;

//$sqlall = "SELECT * FROM vw_content_webkm ";
//$resultall = mysqli_query($conn, $sqlall);

//print_r($resultall);
//var_dump($resultall);

$sqlcontenttype = "SELECT * FROM vw_content_webkm WHERE CONTENT_TYPE_ID = 1  ORDER BY CONTENT_ID DESC LIMIT 30";
//$sqlsks = "SELECT SKILL FROM vw_content_webkm  ";
$resultsqlsks = mysqli_query($conn, $sqlcontenttype);
//$sqlskex = "SELECT SKILL FROM vw_content_webkm ";
//$resultskex = mysqli_query($conn, $sqlskex);
//$resultcontent = mysqli_query($conn, $sqlcontenttype);
//echo("<br>");
//print_r( $resultsqlsks);
//print_r($resultsqlsks);
if(mysqli_num_rows($resultsqlsks) !== null){
	while($rowsks = mysqli_fetch_assoc($resultsqlsks)){
		 $Resssks[] = array(
			'skillsks' => $rowsks['SKILL'],
		 );
		 //echo $rowsks['SKILL'];
		//print_r($rowsks);
		$exp=explode('|',$rowsks['SKILL']);
		//echo("in while ");
		//print_r($exp);
		//print_r($rowsks);
		//print_r($exp);
		//print_r($exp);

		//print_r($SkillEx);
		//print_r($exp);
		//print_r($SkillEx);
		//print_r($exp);
		if(array_intersect($SkillEx,$exp)){
			//echo("In array");
			//print_r($rowsks);
			// $i = 1;
			// while (array_intersect($SkillEx,$exp)){
			// 	$jsoned[$i]['TOPIC'] = $rowsks['TOPIC'];
			// 	$jsoned[$i]['CONTENT_ID'] = $rowsks['CONTENT_ID'];
			// 	$i++;
			
			// }
			
			$newArray[] = array(
			'topic' => $rowsks['TOPIC'],
			//'cate_id' => $rowsks['CONTENT_ID'],
			'subcatename' => $rowsks['SUBCATEGORY_NAME'],
			'cate_name' => $rowsks['CATEGORY_NAME'],
			'description' => $rowsks['DESCRIPTION'],
			//'type' => $rowsks['CONTENT_TYPE_NAME'],
			//'sk' => $rowsks['SKILL'],
			//'content_id' => $rowsks['CONTENT_ID'],
			);
			

			$jsoned = str_replace('][',",",json_encode($newArray,JSON_UNESCAPED_UNICODE));
			//echo $json;
			$jsoned = str_replace('][',"ssss", $jsoned);
			
			//$jsoned = preg_replace('][',',',$jsoned);
			echo $jsoned;
			//$newArray = json_encode($newArray,JSON_UNESCAPED_UNICODE);
			//$rowsks = json_encode($rowsks,JSON_UNESCAPED_UNICODE);
			//echo($newArray);

			//print_r($rowsks);
			//$json = json_encode($newArray);
				// // foreach((array)$newArray as $sing){
			// 	echo 'topic' . $sing->topic;
			// 	echo"<br>";
			// 	echo 'cate_name' . $sing->name;
			// 	echo "<br>";
			// }
			//echo json_encode($newArray,JSON_UNESCAPED_UNICODE);
			// }
			//$json = json_encode($ress,JSON_UNESCAPED_UNICODE);
			//echo $rowsks['TOPIC'];
			//$json = json_encode($rowsks,JSON_UNESCAPED_UNICODE);
			//echo(json_encode($rowsks['DESCRIPTION'],JSON_UNESCAPED_UNICODE) );
			// print_r($rowsks['CONTENT_ID']);
			// echo("<br>");
			// print_r($rowsks['TOPIC']);
			// echo("<br>");
			// // print_r($rowsks['SKILL']);
			// // echo("<br>");
			// // print_r($rowsks['FILE_ATTACH']);
			// print_r($rowsks['CATEGORY_NAME']);
			// echo("<br>");
			// print_r($rowsks['SUBCATEGORY_NAME']);
			// echo("<br>");
			


			//print_r($rowsks['DESCRIPTION']);
			//echo $json;


			
			//print_r($exp);
			//echo(count($rowsks['SKILL']));
			//print_r($rowsks['TOPIC']);
			//echo $rowsks['TOPIC'];
			//echo $rowsks['CATEGORY_NAME'];
		}

	}
	//echo("In array");
	//print_r($rowsks);
	// if(mysqli_num_rows($Resssks) !== null){
	// 	while($rowsks2 = mysqli_fetch_assoc($Resssks)){
	// 		$Resssks_2[] = array(
	// 		'skillsks2' => $rowsks2['skillsks']
	// 		);
	// 	}
	// }
}
//print_r($Resssks);
//$Fin_sks = explode("|",$Resssks);
//echo $Fin_sks;
//print_r($resultcontent);
//var_dump($resultcontent);



//$exskex = explode("|",$resultskex);
//print_r($exskex);
//print_r($resultskex);
//echo $resultskex;
//$sqlskill ="SELECT * FROM vw_content_webkm WHERE CONTENT_TYPE_ID = 1 and SKILL = $SkillEx";
//$resultskill = mysqli_query($conn, $sqlskill);
//echo $resultskill;
//print_r($result);
//echo $_SESSION['skills_j'];
//echo $_REQUEST['skills_j'];
//$_GET['skill_sent'];
// echo $_GET['skill_sent'];
// echo $_REQUEST['skill_sent'];
// echo $_COOKIE['skill_sent'];
// echo $_SERVER['skill_sent'];


//$response = file_get_contents('http://10.183.252.51/sing9/web/login_front.php?Skill='.$Skill);
//$response = $Skill;
//print_r($response);
//print_r($Skill);

//$url = 'http://10.183.252.51/sing9/web/login_front.php';
//$json = file_get_contents($url);
//$jsoned = json_encode($json);
//echo $jsoned;
?>

