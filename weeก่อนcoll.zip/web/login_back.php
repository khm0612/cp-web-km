<?php
//session_start();
ob_start();

//header('Content-Type: application/json');
//header("Content-type:application/json; charset=UTF-8");
//header("Cache-Control: no-store, no-cache, must-revalidate");
//header("Cache-Control: GET-check=0, pre-check=0", false);

$Db_Servername = 'webkm'; 
$Db_Username = 'root'; 
$Db_Password = 'dbwebkm@2016'; 
$Db_name = 'webkm'; 

$conn = mysqli_connect($Db_Servername, $Db_Username, $Db_Password, $Db_name);
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}
//$sqlAll = 'SELECT * FROM vw_employee_webkm';
//$result = mysqli_query($conn, $sql);
//$sqlPass = 'SELECT * FROM vw_employee_webkm WHERE EMP_PASSWORD = ';
//$sqlId   = 'SELECT * FROM vw_employee_webkm WHERE EMP_USERNAME = ';

//Decode token here
//---------
//เอาค่าที่decryptไปเทียบDb
//-------
//Decryptโทเค้น
//-------
//ตรวจค่าที่ส่งมาDb
$Id = $_REQUEST['Id'];
$Password = $_REQUEST['Password'];
$sql="SELECT * FROM vw_employee_webkm Where EMP_USERNAME='".$Id."' and EMP_PASSWORD='".$Password."' ";
$result = mysqli_query($conn,$sql);

$sqlSk = " SELECT SKILL FROM vw_employee_webkm WHERE EMP_USERNAME='".$Id."' and EMP_PASSWORD='".$Password."' ";
$resultSk = mysqli_query($conn,$sqlSk);
//print_r($result);
//var_dump($result);
//echo($result);
//$row = $result->fetch_assoc();


if(mysqli_num_rows($result)==1){
    if(mysqli_num_rows($resultSk)==1){
        //echo("  Respond ResultSk  ----------- ");
        if(mysqli_num_rows($resultSk) > 0){
            while ($rowSk = mysqli_fetch_assoc($resultSk)){
                $RessSk[] = array(
                   // 'emp_code' => $row['EMP_CODE'],
                    //'emp_pass' => $row['EMP_PASSWORD'],
                    'skills'   => $rowSk['SKILL'],
                );
            }
        }
        $Skill_Num = ($RessSk[0]['skills']);
       
        //echo($rowSk);
       // print_r($RessSk);
      // print_r(($RessSk[0]['skills']));
       //$Skill_Num = print_r(($RessSk[0]['skills']));
      // print_r($resultSk[0]['skills']);
       //$Skill_Num = print_r($resultSk[0]['skills']);
       //print_r($RessSk[0]['skills']);
       //var_dump($Skill_Num);
       //print_r($Skill_Num);
       //$Skill_Num <= ($RessSk[0]['skills']);\
       //print_r($Skill_Num);
       
       //explode($Skill_Num,"|");
       //echo(explode($Skill_Num,"|"));

       //echo(count($RessSk));
      // echo(count($rowSk));
        //print_r($rowSk);
        //print_r($resultSk);
        //var_dump($resultSk);
        //echo("  --------------- ");
        
        $_SESSION['skill_sent'] = ($RessSk[0]['skills']);
        //echo(" expire time left :");
        //echo("<pre>");
        //echo($_SESSION['expire']);
        //$expire = $_GET['expire'];
        //echo ($expire);
        //$auths = "true";
        //header('../Home.php');
        //echo("<br>");
        //echo(" Success");
       //echo("<br>");
       if($Skill_Num !== null){
           echo $Skill_Num;
            //echo'inif';
       }
       
       //return $Skill_Num;

    }
    //$row = $result->fetch_assoc();
    //$Id=="emp_id" && $Password==$RessPassword
    /*$EmId = $Id;
    $EmPassword = $Password;
    $_SESSION['luser'] = $EmId;
    $_SESSION['start'] = time();
    $_SESSION['expire'] = $_SESSION['start'] + (30*60);
    echo(" expire time left :");
    //echo("<pre>");
    echo($_SESSION['expire']);
    //$expire = $_GET['expire'];
    //echo ($expire);
    //$auths = "true";
    //header('../Home.php');
    echo("<br>");
    echo(" Success");
    echo("<br>");
        */
    //$loginB = true;
    //$respond = json_encode("Test-ENcode");
    

}else{
   // echo("  auth-fail");
    //var_dump($row['EMP_USERNAME']);
    //var_dump($row['EMP_USERNAME']);
    //var_dump($_GET['emp_pass']);
    //var_dump($ress['emp_id']);
    //echo($_GET['emp_id']);
    //print_r($RessId);
    //var_dump($RessPassword);
    mysqli_close($conn);

}
/*echo("ID:");
print_r($_GET['Id']);
echo("   Password:");
print_r($_GET['Password']);
echo("   expire in:");*/

//echo($_SESSION['expire']);


//เทียบ DB ถ้ามี Search
/*if ($Id) {
	$Result_Search_Db = 'a.TOPIC LIKE "%' . $_GET['x'] . '%" OR a.DESCRIPTION LIKE "%' . $_GET['x'] . '%" OR a.KEYWORD LIKE "%' . $_GET['x'] . '%" ';
} else {
	echo 'Wrong';
}*/