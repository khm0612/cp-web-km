<?php

echo('ripemd160');
echo('<hr>');
echo hash('ripemd160', 'The quick brown fox jumped over the lazy dog.');


?>