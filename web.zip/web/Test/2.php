
<?php
$str = 'This is Main  2|2String';
$substr = "|";
 
if(is_numeric(9|5)){
    echo 'truue';
}else{
    echo'false';
}

?>