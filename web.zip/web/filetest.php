<html>

<?php
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header("Content-type:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet; charset=UTF-8");
echo("s");
?>

</html>