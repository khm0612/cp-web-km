<?php
$json= file_get_contents('http://gocalwi01/WsApp/SearchKM/back/homeback.php?skill="9|5"');
echo $json;