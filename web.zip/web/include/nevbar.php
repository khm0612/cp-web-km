<!-- navbar -->


<link rel="stylesheet" href="usestyle.css">
<nav class="navbar navbar-expand-lg" style="background-color:red">
    <div class="container-fluid">
        <a class="navbar-brand">
            <div class="FontNav">
                Gosoft
            </div>
        </a>

    </div>
</nav>