print('x')
