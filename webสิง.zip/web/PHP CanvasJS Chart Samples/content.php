    <!-- page-content-wrapper -->
    <div id="page-content-wrapper" class="page-content-toggle">
        <div class="container-fluid">            

            <div class="row">
                <div id="content" class="col-md-8 col-md-offset-1 col-xs-12">